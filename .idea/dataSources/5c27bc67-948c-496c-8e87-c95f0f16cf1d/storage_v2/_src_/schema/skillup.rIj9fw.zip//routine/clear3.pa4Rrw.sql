create
    definer = root@`%` procedure clear3()
begin
  truncate table users;
  truncate table products;
  truncate table orders;
end;

